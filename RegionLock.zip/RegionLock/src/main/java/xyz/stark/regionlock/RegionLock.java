package xyz.stark.regionlock;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class RegionLock extends JavaPlugin implements Listener {

    private static final String WAND_NAME = "§6Region Wand";

    private final Map<String, Region> regions = new HashMap<>();
    private final Map<UUID, Location> pos1 = new HashMap<>();
    private final Map<UUID, Location> pos2 = new HashMap<>();
    private File dataFile;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "regions.yml");
        loadRegions();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("RegionLock enabled, regions loaded: " + regions.size());
    }

    // ---------- Commands ----------
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (!p.hasPermission("regionlock.admin")) {
            p.sendMessage("§cYou don't have permission.");
            return true;
        }
        if (args.length == 0) {
            p.sendMessage("§e/region wand §7- Get the selection wand");
            p.sendMessage("§e/region create <name> §7- Create a region from your selection");
            p.sendMessage("§e/region delete <name> §7- Delete a region");
            p.sendMessage("§e/region list §7- List all regions");
            p.sendMessage("§e/region reload §7- Reload config.yml");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "wand" -> {
                ItemStack wand = new ItemStack(Material.GOLDEN_AXE);
                ItemMeta meta = wand.getItemMeta();
                meta.setDisplayName(WAND_NAME);
                meta.setLore(List.of("§7Left click: Position 1", "§7Right click: Position 2"));
                wand.setItemMeta(meta);
                p.getInventory().addItem(wand);
                p.sendMessage("§aYou received the selection wand.");
            }
            case "create" -> {
                if (args.length < 2) { p.sendMessage("§cUsage: /region create <name>"); return true; }
                String name = args[1].toLowerCase();
                if (!name.matches("[a-z0-9_-]+")) {
                    p.sendMessage("§cName can only contain letters, numbers, _ and -.");
                    return true;
                }
                if (regions.containsKey(name)) { p.sendMessage("§cA region with that name already exists."); return true; }
                Location a = pos1.get(p.getUniqueId());
                Location b = pos2.get(p.getUniqueId());
                if (a == null || b == null) { p.sendMessage("§cSelect both positions with the wand first."); return true; }
                if (!a.getWorld().equals(b.getWorld())) { p.sendMessage("§cBoth positions must be in the same world."); return true; }

                Region r = new Region(name, a.getWorld().getName(),
                        Math.min(a.getBlockX(), b.getBlockX()), Math.min(a.getBlockY(), b.getBlockY()), Math.min(a.getBlockZ(), b.getBlockZ()),
                        Math.max(a.getBlockX(), b.getBlockX()), Math.max(a.getBlockY(), b.getBlockY()), Math.max(a.getBlockZ(), b.getBlockZ()));
                regions.put(name, r);
                registerPermission(name);
                saveRegions();
                p.sendMessage("§aRegion §e" + name + " §acreated.");
                p.sendMessage("§aPermission: §e" + permOf(name));
            }
            case "delete" -> {
                if (args.length < 2) { p.sendMessage("§cUsage: /region delete <name>"); return true; }
                String name = args[1].toLowerCase();
                if (regions.remove(name) == null) { p.sendMessage("§cRegion not found."); return true; }
                getServer().getPluginManager().removePermission(permOf(name));
                saveRegions();
                p.sendMessage("§aRegion §e" + name + " §adeleted.");
            }
            case "list" -> {
                if (regions.isEmpty()) { p.sendMessage("§7No regions yet."); return true; }
                regions.keySet().forEach(n -> p.sendMessage("§e" + n + " §7-> §f" + permOf(n)));
            }
            case "reload" -> {
                reloadConfig();
                p.sendMessage("§aConfig reloaded.");
            }
            default -> p.sendMessage("§cUnknown subcommand.");
        }
        return true;
    }

    // ---------- Tab completion ----------
    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (!sender.hasPermission("regionlock.admin")) return Collections.emptyList();

        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            options.addAll(List.of("wand", "create", "delete", "list", "reload"));
        } else if (args.length == 2 && args[0].equalsIgnoreCase("delete")) {
            options.addAll(regions.keySet());
        } else if (args.length == 2 && args[0].equalsIgnoreCase("create")) {
            options.add("<name>");
        }

        String typed = args[args.length - 1].toLowerCase();
        options.removeIf(o -> !o.toLowerCase().startsWith(typed));
        return options;
    }

    // ---------- Wand selection ----------
    @EventHandler
    public void onWand(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getClickedBlock() == null) return;
        Player p = e.getPlayer();
        ItemStack item = p.getInventory().getItemInMainHand();
        if (item.getType() != Material.GOLDEN_AXE || !item.hasItemMeta()
                || !WAND_NAME.equals(item.getItemMeta().getDisplayName())) return;
        if (!p.hasPermission("regionlock.admin")) return;

        Location loc = e.getClickedBlock().getLocation();
        if (e.getAction() == Action.LEFT_CLICK_BLOCK) {
            pos1.put(p.getUniqueId(), loc);
            p.sendMessage("§aPosition 1: §f" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ());
            e.setCancelled(true);
        } else if (e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            pos2.put(p.getUniqueId(), loc);
            p.sendMessage("§aPosition 2: §f" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ());
            e.setCancelled(true);
        }
    }

    // ---------- Block break protection ----------
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Location l = e.getBlock().getLocation();
        for (Region r : regions.values()) {
            if (r.contains(l) && !e.getPlayer().hasPermission(permOf(r.name))) {
                e.setCancelled(true);
                String msg = getConfig().getString("no-permission-message",
                        "&cYou can't break blocks here!")
                        .replace("{region}", r.name)
                        .replace("{permission}", permOf(r.name))
                        .replace("{player}", e.getPlayer().getName());
                e.getPlayer().sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
                return;
            }
        }
    }

    // ---------- Permissions ----------
    private String permOf(String name) {
        return "region." + name;
    }

    private void registerPermission(String name) {
        try {
            getServer().getPluginManager().addPermission(new Permission(permOf(name), PermissionDefault.FALSE));
        } catch (IllegalArgumentException ignored) { }
    }

    // ---------- Save / load ----------
    private void saveRegions() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Region r : regions.values()) {
            String k = r.name + ".";
            yml.set(k + "world", r.world);
            yml.set(k + "x1", r.x1); yml.set(k + "y1", r.y1); yml.set(k + "z1", r.z1);
            yml.set(k + "x2", r.x2); yml.set(k + "y2", r.y2); yml.set(k + "z2", r.z2);
        }
        try {
            getDataFolder().mkdirs();
            yml.save(dataFile);
        } catch (IOException ex) {
            getLogger().severe("Failed to save regions: " + ex.getMessage());
        }
    }

    private void loadRegions() {
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        for (String name : yml.getKeys(false)) {
            String k = name + ".";
            regions.put(name, new Region(name, yml.getString(k + "world"),
                    yml.getInt(k + "x1"), yml.getInt(k + "y1"), yml.getInt(k + "z1"),
                    yml.getInt(k + "x2"), yml.getInt(k + "y2"), yml.getInt(k + "z2")));
            registerPermission(name);
        }
    }

    // ---------- Region ----------
    private static class Region {
        final String name, world;
        final int x1, y1, z1, x2, y2, z2;

        Region(String name, String world, int x1, int y1, int z1, int x2, int y2, int z2) {
            this.name = name; this.world = world;
            this.x1 = x1; this.y1 = y1; this.z1 = z1;
            this.x2 = x2; this.y2 = y2; this.z2 = z2;
        }

        boolean contains(Location l) {
            World w = l.getWorld();
            return w != null && w.getName().equals(world)
                    && l.getBlockX() >= x1 && l.getBlockX() <= x2
                    && l.getBlockY() >= y1 && l.getBlockY() <= y2
                    && l.getBlockZ() >= z1 && l.getBlockZ() <= z2;
        }
    }
}
